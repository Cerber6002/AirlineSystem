create function dept_count(dept_name character varying) returns integer
    language plpgsql
as
$$
DECLARE
    d_count INTEGER;
BEGIN
    -- Select the count into the variable
    SELECT COUNT(*) INTO d_count
    FROM instructor
    WHERE instructor.dept_name = dept_name;

    -- Return the count
    RETURN d_count;
END;
$$;

alter function dept_count(varchar) owner to postgres;

